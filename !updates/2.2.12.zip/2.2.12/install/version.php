<?
$arModuleVersion = array(
    "VERSION" => "2.2.12",
    "VERSION_DATE" => "2020-10-02 17:02:00"
);
