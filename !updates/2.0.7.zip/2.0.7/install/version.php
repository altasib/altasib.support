<?
#################################################
#   Company developer: ALTASIB                  #
#   Developer: Evgeniy Pedan                    #
#   Site: http://www.altasib.ru                 #
#   E-mail: dev@altasib.ru                      #
#   Copyright (c) 2006-2017 ALTASIB             #
#################################################
?>
<?
$arModuleVersion = array(
        "VERSION" => "2.0.7",
        "VERSION_DATE" => "2017-01-25 14:53:00"
);
?>
