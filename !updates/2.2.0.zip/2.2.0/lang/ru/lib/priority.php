<?
#################################################
#   Company developer: ALTASIB                  #
#   Developer: Evgeniy Pedan                    #
#   Site: http://www.altasib.ru                 #
#   E-mail: dev@altasib.ru                      #
#   Copyright (c) 2006-2013 ALTASIB             #
#################################################
?>
<?
$MESS["ALTASIB_SUPPORT_PRIORITY_HIGHT"] = "�������";
$MESS["ALTASIB_SUPPORT_PRIORITY_NORMAL"] = "����������";
$MESS["ALTASIB_SUPPORT_PRIORITY_LOW"] = "������";
?>