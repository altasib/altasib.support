<?php
/**
 * ALTASIB
 * @site http://www.altasib.ru
 * @email dev@altasib.ru
 * @copyright 2006-2018 ALTASIB
 */
$arModuleVersion = array(
        "VERSION" => "2.2.0",
        "VERSION_DATE" => "2018-05-16 15:02:00"
);