<?php
/**
 * ALTASIB
 * @site http://www.altasib.ru
 * @email dev@altasib.ru
 * @copyright 2006-2018 ALTASIB
 */
$arModuleVersion = array(
        "VERSION" => "2.2.1",
        "VERSION_DATE" => "2018-07-04 12:02:00"
);