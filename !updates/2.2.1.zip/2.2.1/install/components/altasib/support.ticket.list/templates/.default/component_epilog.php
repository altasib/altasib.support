<?
#################################################
#   Company developer: ALTASIB                  #
#   Developer: Evgeni� Pedan                    #
#   Site: http://www.altasib.ru                 #
#   E-mail: dev@altasib.ru                      #
#   Copyright (c) 2006-2013 ALTASIB             #
#################################################
?>
<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();


$APPLICATION->SetAdditionalCSS('/bitrix/components/bitrix/main.interface.grid/templates/.default/themes/lightgrey/style.css');
$APPLICATION->SetAdditionalCSS('/bitrix/components/altasib/support.ticket.list/templates/.default/theme/style.css');
?>