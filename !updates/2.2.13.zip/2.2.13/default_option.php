<?
$altasib_support_default_option = array(
	'path_list' => '/support/',
	'path_detail' => '/support/ticket/#ID#/',
	'path_file' => '/support/ticket/#ID#/file/#FILE_HASH#/',
	'path_group_list' => '/workgroups/group/#group_id#/support/',
	'path_group_detail' => '/workgroups/group/#group_id#/support/ticket/#ID#/',
	'path_group_file' => '/workgroups/group/#group_id#/support/ticket/#ID#/file/#FILE_HASH#/'
);
