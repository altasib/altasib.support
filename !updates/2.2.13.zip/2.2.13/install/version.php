<?
$arModuleVersion = array(
    "VERSION" => "2.2.13",
    "VERSION_DATE" => "2021-03-15 16:34:00"
);
