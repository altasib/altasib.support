<?
#################################################
#   Company developer: ALTASIB                  #
#   Developer: Evgeniy Pedan                    #
#   Site: http://www.altasib.ru                 #
#   E-mail: dev@altasib.ru                      #
#   Copyright (c) 2006-2017 ALTASIB             #
#################################################
?>
<?
$arModuleVersion = array(
        "VERSION" => "2.1.1",
        "VERSION_DATE" => "2017-03-03 13:31:00"
);
?>
