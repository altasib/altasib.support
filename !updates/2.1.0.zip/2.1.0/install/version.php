<?
#################################################
#   Company developer: ALTASIB                  #
#   Developer: Evgeniy Pedan                    #
#   Site: http://www.altasib.ru                 #
#   E-mail: dev@altasib.ru                      #
#   Copyright (c) 2006-2017 ALTASIB             #
#################################################
?>
<?
$arModuleVersion = array(
        "VERSION" => "2.1.0",
        "VERSION_DATE" => "2017-01-25 15:08:00"
);
?>
