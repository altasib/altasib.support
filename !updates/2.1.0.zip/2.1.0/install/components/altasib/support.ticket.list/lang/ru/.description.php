<?
#################################################
#   Company developer: ALTASIB                  #
#   Developer: Evgeni� Pedan                    #
#   Site: http://www.altasib.ru                 #
#   E-mail: dev@altasib.ru                      #
#   Copyright (c) 2006-2010 ALTASIB             #
#################################################
?>
<?
$MESS["ALTASIB_SUPPORT"] = "������ ���������";
$MESS["ALTASIB_SUPPORT_DESC"] = "";
$MESS["ALTASIB_DESC_SECTION_NAME"] = "IS-MARKET.RU";
$MESS["ALTASIB_DESC_SUPPORT_SECTION_NAME"] = "���. ���������";
?>